目前分析过程中遇到的问题
---------
#### 一. Demo 网络请求无稳定后台
- Volley Demo 目前无稳定 post 请求后台 
  http测试可以使用[http://httpbin.org/](http://httpbin.org/)
