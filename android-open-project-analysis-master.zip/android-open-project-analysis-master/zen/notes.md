一些注意事项
============
### 1. Git
#### 1.1 在 Windows 下使用 Git 的，需要配置下  
`git config --global core.autocrlf true`   
防止将 Windows 的换行提交到了仓库中，其他系统忽略这个问题  

#### 1.2. 禁止使用 push 的 force 选项，如  
`git push --force`   
特殊情况请现在群里说明  
